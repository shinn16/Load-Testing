ds2_mysql_web_php_readme.txt

php4 interface to the MySQL DVD Store database
Requires php4/MySQL4
Files:

dscommon.inc
dspurchase.php
dsnewcustomer.php
dsbrowse.php
dslogin.php

The driver programs expect these files in a virtual directory "ds2".
In your web server you either need to create a virtual directory that points
to this directory or copy these files to the appropriate directory (eg /var/www/html/ds2)

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  9/21/05
