ds2_mysql_web_readme.txt

The MySQL DVD Store currently has three web application interfaces, PHP, JSP and ASPX

For the ds2webdriver program and source, see ./ds2/drivers

Directories
-----------
./ds2/mysqlds2/web
./ds2/mysqlds2/web/php4        php4 pages 
./ds2/mysqlds2/web/php5        php5 pages 
./ds2/mysqlds2/web/jsp         jsp pages 
./ds2/mysqlds2/web/aspx        aspx pages 

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  9/21/05
