ds2_mysql_load_cust_readme.txt

Instructions for loading DVD Store Version 2 (DS2) database customer data
(assumes data files are in directory ../../../data_files/cust)

  mysql --password=pw < mysqlds2_load_cust.sql

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  5/13/05
